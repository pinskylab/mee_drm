## -----------------------------------------------------------------------------
#| eval: false

## remotes::install_github("pinskylab/drmr")


## -----------------------------------------------------------------------------
#| label: setup

library(drmr)
library(sf) ## "mapping"
library(ggplot2) ## graphs
library(bayesplot) ## and more graphs
library(dplyr)


## -----------------------------------------------------------------------------
#| label: data-load

## loads the data
data(sum_fl)

## computing density
sum_fl <- sum_fl |>
  mutate(dens = 100 * y / area_km2,
         .before = y)


## -----------------------------------------------------------------------------
#| label: data-split

## 5 years-ahead predictions
first_year_forecast <- max(sum_fl$year) - 4

first_id_forecast <-
  first_year_forecast - min(sum_fl$year) + 1

years_all <- order(unique(sum_fl$year))
years_train <- years_all[years_all < first_id_forecast]
years_test <- years_all[years_all >= first_id_forecast]

## splitting data
dat_test <- sum_fl |>
  filter(year >= first_year_forecast)

dat_train <- sum_fl |>
  filter(year < first_year_forecast)


## -----------------------------------------------------------------------------
#| label: center-scale

avgs <- c("stemp" = mean(dat_train$stemp),
          "btemp" = mean(dat_train$btemp),
          "depth" = mean(dat_train$depth),
          "n_hauls" = mean(dat_train$n_hauls),
          "lat" = mean(dat_train$lat),
          "lon" = mean(dat_train$lon))

min_year <- dat_train$year |>
  min()

## centering covariates
dat_train <- dat_train |>
  mutate(c_stemp = stemp - avgs["stemp"],
         c_btemp = btemp - avgs["btemp"],
         c_hauls = n_hauls - avgs["n_hauls"],
         c_lat   = lat - avgs["lat"],
         c_lon   = lon - avgs["lon"],
         time  = year - min_year)

dat_test <- dat_test |>
  mutate(c_stemp = stemp - avgs["stemp"],
         c_btemp = btemp - avgs["btemp"],
         c_hauls = n_hauls - avgs["n_hauls"],
         c_lat   = lat - avgs["lat"],
         c_lon   = lon - avgs["lon"],
         time  = year - min_year)


## -----------------------------------------------------------------------------
#| label: baseline_mock
#| eval: false

## baseline <-
##   fit_drm(.data = dat_train,
##           y_col    = "dens", ## response variable: density
##           time_col = "year", ## vector of time points
##           site_col = "patch",
##           seed = 202505)


## -----------------------------------------------------------------------------
#| label: baseline
#| eval: false
#| echo: false

## if (instantiate::stan_cmdstan_exists()) {
##   baseline <-
##     fit_drm(.data = dat_train,
##             y_col    = "dens", ## response variable: density
##             time_col = "year", ## vector of time points
##             site_col = "patch",
##             seed = 202505)
## }


## -----------------------------------------------------------------------------
#| label: simplest_fit_mock
#| eval: false

## drm_1 <-
##   fit_drm(.data = dat_train,
##           y_col = "dens",
##           time_col = "year",
##           site_col = "patch",
##           seed = 202505,
##           formula_zero = ~ 1 + c_hauls + c_btemp + c_stemp,
##           formula_rec = ~ 1 + c_stemp + I(c_stemp * c_stemp),
##           init = "cmdstan_default")


## -----------------------------------------------------------------------------
#| label: simplest_fit
#| eval: false
#| echo: false

## if (instantiate::stan_cmdstan_exists()) {
##   drm_1 <-
##     fit_drm(.data = dat_train,
##             y_col = "dens",
##             time_col = "year",
##             site_col = "patch",
##             seed = 202505,
##             formula_zero = ~ 1 + c_hauls + c_btemp + c_stemp,
##             formula_rec = ~ 1 + c_stemp + I(c_stemp * c_stemp),
##             init = "cmdstan_default")
## }


## -----------------------------------------------------------------------------
#| label: drms_moc
#| eval: false

## drm_2 <-
##   fit_drm(.data = dat_train,
##           y_col = "dens", ## response variable: density
##           time_col = "year", ## vector of time points
##           site_col = "patch",
##           seed = 202505,
##           formula_zero = ~ 1 + c_hauls + c_btemp + c_stemp,
##           formula_rec = ~ 1 + c_stemp + c_stemp * c_stemp,
##           formula_surv = ~ 1,
##           m = 0,
##           .toggles = list(est_surv = 1))
## 
## drm_3 <-
##   fit_drm(.data = dat_train,
##           y_col = "dens", ## response variable: density
##           time_col = "year", ## vector of time points
##           site_col = "patch",
##           seed = 202505,
##           formula_zero = ~ 1 + c_hauls + c_btemp + c_stemp,
##           formula_rec = ~ 1 + c_stemp + I(c_stemp * c_stemp),
##           formula_surv = ~ 1,
##           .toggles = list(est_surv = 1,
##                           ar_re = "rec"))
## ## loading map
## map_name <- system.file("maps/sum_fl.shp", package = "drmr")
## 
## polygons <- st_read(map_name)
## 
## adj_mat <- gen_adj(st_buffer(st_geometry(polygons),
##                              dist = 2500))
## 
## ## row-standardized matrix
## adj_mat <-
##   t(apply(adj_mat, 1, \(x) x / (sum(x))))
## 
## drm_4 <-
##   fit_drm(.data = dat_train,
##           y_col = "dens", ## response variable: density
##           time_col = "year", ## vector of time points
##           site_col = "patch",
##           family = "gamma",
##           seed = 202505,
##           formula_zero = ~ 1 + c_hauls + c_btemp + c_stemp,
##           formula_rec = ~ 1 + c_stemp + I(c_stemp * c_stemp),
##           formula_surv = ~ 1,
##           n_ages = 6,
##           adj_mat = adj_mat, ## A matrix for movement routine
##           ages_movement = c(0, 0, 1, 1, 1, 0), ## ages allowed to move
##           .toggles = list(est_surv = 1,
##                           ar_re = "rec",
##                           movement = 1))
## 
## drm_5 <-
##   fit_drm(.data = dat_train,
##           y_col = "dens", ## response variable: density
##           time_col = "year", ## vector of time points
##           site_col = "patch",
##           family = "gamma",
##           seed = 202505,
##           formula_zero = ~ 1 + c_hauls + c_btemp + c_stemp,
##           formula_rec = ~ 1 + c_stemp + I(c_stemp * c_stemp),
##           formula_surv = ~ 1,
##           n_ages = 6,
##           .toggles = list(est_surv = 1,
##                           ar_re = "rec"))
## 
## ## instantaneous fishing mortality rates
## fmat <-
##   system.file("fmat.rds", package = "drmr") |>
##   readRDS()
## 
## f_train <- fmat[, years_train]
## f_test  <- fmat[, years_test]
## 
## drm_6 <-
##   fit_drm(.data = dat_train,
##           y_col = "dens", ## response variable: density
##           time_col = "year", ## vector of time points
##           site_col = "patch",
##           family = "gamma",
##           seed = 202505,
##           formula_zero = ~ 1 + c_hauls + c_btemp + c_stemp,
##           formula_rec = ~ 1 + c_stemp + I(c_stemp * c_stemp),
##           formula_surv = ~ 1,
##           n_ages = NROW(f_train),
##           f_mort = f_train,
##           .toggles = list(ar_re = "rec",
##                           est_surv = 1))
## 
## drm_7 <-
##   fit_drm(.data = dat_train,
##           y_col = "dens", ## response variable: density
##           time_col = "year", ## vector of time points
##           site_col = "patch",
##           family = "gamma",
##           seed = 202505,
##           formula_zero = ~ 1 + c_hauls + c_btemp + c_stemp,
##           formula_rec = ~ 1,
##           formula_surv = ~ 1 + c_btemp + I(c_btemp * c_btemp),
##           .toggles = list(ar_re = "rec",
##                           est_surv = 1))
## 
## sdm <-
##   fit_sdm(.data = dat_train,
##           y_col = "dens", ## response variable: density
##           time_col = "year", ## vector of time points
##           site_col = "patch",
##           seed = 202505,
##           formula_zero = ~ 1 + c_hauls + c_btemp + c_stemp,
##           formula_dens = ~ 1 + c_stemp + I(c_stemp * c_stemp),
##           .toggles = list(ar_re = "rec"))


## -----------------------------------------------------------------------------
#| label: drms
#| eval: false
#| echo: false

## if (instantiate::stan_cmdstan_exists()) {
## drm_2 <-
##   fit_drm(.data = dat_train,
##           y_col = "dens", ## response variable: density
##           time_col = "year", ## vector of time points
##           site_col = "patch",
##           seed = 202505,
##           formula_zero = ~ 1 + c_hauls + c_btemp + c_stemp,
##           formula_rec = ~ 1 + c_stemp + c_stemp * c_stemp,
##           formula_surv = ~ 1,
##           m = 0,
##           .toggles = list(est_surv = 1))
## 
## drm_3 <-
##   fit_drm(.data = dat_train,
##           y_col = "dens", ## response variable: density
##           time_col = "year", ## vector of time points
##           site_col = "patch",
##           seed = 202505,
##           formula_zero = ~ 1 + c_hauls + c_btemp + c_stemp,
##           formula_rec = ~ 1 + c_stemp + I(c_stemp * c_stemp),
##           formula_surv = ~ 1,
##           .toggles = list(est_surv = 1,
##                           ar_re = "rec"))
## 
## ## loading map
## map_name <- system.file("maps/sum_fl.shp", package = "drmr")
## 
## polygons <- st_read(map_name)
## 
## adj_mat <- gen_adj(st_buffer(st_geometry(polygons),
##                              dist = 2500))
## 
## ## row-standardized matrix
## adj_mat <-
##   t(apply(adj_mat, 1, \(x) x / (sum(x))))
## 
## drm_4 <-
##   fit_drm(.data = dat_train,
##           y_col = "dens", ## response variable: density
##           time_col = "year", ## vector of time points
##           site_col = "patch",
##           family = "gamma",
##           seed = 202505,
##           formula_zero = ~ 1 + c_hauls + c_btemp + c_stemp,
##           formula_rec = ~ 1 + c_stemp + I(c_stemp * c_stemp),
##           formula_surv = ~ 1,
##           n_ages = 6,
##           adj_mat = adj_mat, ## A matrix for movement routine
##           ages_movement = c(0, 0, 1, 1, 1, 0), ## ages allowed to move
##           .toggles = list(est_surv = 1,
##                           ar_re = "rec",
##                           movement = 1))
## 
## drm_5 <-
##   fit_drm(.data = dat_train,
##           y_col = "dens", ## response variable: density
##           time_col = "year", ## vector of time points
##           site_col = "patch",
##           family = "gamma",
##           seed = 202505,
##           formula_zero = ~ 1 + c_hauls + c_btemp + c_stemp,
##           formula_rec = ~ 1 + c_stemp + I(c_stemp * c_stemp),
##           formula_surv = ~ 1,
##           n_ages = 6,
##           .toggles = list(est_surv = 1,
##                           ar_re = "rec"))
## 
## ## instantaneous fishing mortality rates
## fmat <-
##   system.file("fmat.rds", package = "drmr") |>
##   readRDS()
## 
## f_train <- fmat[, years_train]
## f_test  <- fmat[, years_test]
## 
## drm_6 <-
##   fit_drm(.data = dat_train,
##           y_col = "dens", ## response variable: density
##           time_col = "year", ## vector of time points
##           site_col = "patch",
##           family = "gamma",
##           seed = 202505,
##           formula_zero = ~ 1 + c_hauls + c_btemp + c_stemp,
##           formula_rec = ~ 1 + c_stemp + I(c_stemp * c_stemp),
##           formula_surv = ~ 1,
##           n_ages = NROW(f_train),
##           f_mort = f_train,
##           .toggles = list(ar_re = "rec",
##                           est_surv = 1))
## 
## drm_7 <-
##   fit_drm(.data = dat_train,
##           y_col = "dens", ## response variable: density
##           time_col = "year", ## vector of time points
##           site_col = "patch",
##           family = "gamma",
##           seed = 202505,
##           formula_zero = ~ 1 + c_hauls + c_btemp + c_stemp,
##           formula_rec = ~ 1,
##           formula_surv = ~ 1 + c_btemp + I(c_btemp * c_btemp),
##           .toggles = list(ar_re = "rec",
##                           est_surv = 1))
## 
## sdm <-
##   fit_sdm(.data = dat_train,
##           y_col = "dens", ## response variable: density
##           time_col = "year", ## vector of time points
##           site_col = "patch",
##           seed = 202505,
##           formula_zero = ~ 1 + c_hauls + c_btemp + c_stemp,
##           formula_dens = ~ 1 + c_stemp + I(c_stemp * c_stemp),
##           .toggles = list(ar_re = "rec"))
## }


## -----------------------------------------------------------------------------
#| label: loo_mock
#| eval: false

## loos <- list("baseline" = baseline$stanfit$loo(),
##              "drm_1" = drm_1$stanfit$loo(),
##              "drm_2" = drm_2$stanfit$loo(),
##              "drm_3" = drm_3$stanfit$loo(),
##              "drm_4" = drm_4$stanfit$loo(),
##              "drm_5" = drm_5$stanfit$loo(),
##              "drm_6" = drm_6$stanfit$loo(),
##              "drm_7" = drm_7$stanfit$loo(),
##              "sdm"   = sdm$stanfit$loo())
## 
## loos_out <- loo::loo_compare(loos)


## -----------------------------------------------------------------------------
#| label: loo
#| eval: false
#| echo: false

## if (instantiate::stan_cmdstan_exists()) {
##   loos <- list("baseline" = baseline$stanfit$loo(),
##                "drm_1" = drm_1$stanfit$loo(),
##                "drm_2" = drm_2$stanfit$loo(),
##                "drm_3" = drm_3$stanfit$loo(),
##                "drm_4" = drm_4$stanfit$loo(),
##                "drm_5" = drm_5$stanfit$loo(),
##                "drm_6" = drm_6$stanfit$loo(),
##                "drm_7" = drm_7$stanfit$loo(),
##                "sdm"   = sdm$stanfit$loo())
## 
##   loos_out <- loo::loo_compare(loos)
## }


## -----------------------------------------------------------------------------
#| label: forecasts_mock
#| eval: false

## forecast_0 <- predict_drm(drm = baseline,
##                           new_data = dat_test,
##                           seed = 125,
##                           cores = 4)
## 
## forecast_1 <- predict_drm(drm = drm_1,
##                           new_data = dat_test,
##                           seed = 125,
##                           cores = 4)
## 
## forecast_2 <- predict_drm(drm = drm_2,
##                           new_data = dat_test,
##                           past_data = filter(dat_train,
##                                              year == max(year)),
##                           seed = 125,
##                           cores = 4)
## 
## forecast_3 <- predict_drm(drm = drm_3,
##                           new_data = dat_test,
##                           past_data = filter(dat_train,
##                                              year == max(year)),
##                           seed = 125,
##                           cores = 4)
## 
## forecast_4 <- predict_drm(drm = drm_4,
##                           new_data = dat_test,
##                           past_data = filter(dat_train,
##                                              year == max(year)),
##                           seed = 125,
##                           cores = 4)
## 
## forecast_5 <- predict_drm(drm = drm_5,
##                           new_data = dat_test,
##                           past_data = filter(dat_train,
##                                              year == max(year)),
##                           seed = 125,
##                           cores = 4)
## 
## forecast_6 <- predict_drm(drm = drm_6,
##                           new_data = dat_test,
##                           past_data = filter(dat_train,
##                                              year == max(year)),
##                           f_test = f_test,
##                           seed = 125,
##                           cores = 4)
## 
## forecast_7 <- predict_drm(drm = drm_7,
##                           new_data = dat_test,
##                           past_data = filter(dat_train,
##                                              year == max(year)),
##                           seed = 125,
##                           cores = 4)
## 
## forecast_sdm <-
##   predict_sdm(sdm = sdm,
##               new_data = dat_test,
##               seed = 125,
##               cores = 4)
## 
## ##--- summarizing forecasts ----
## 
## all_forecasts <-
##   ls(pattern = "^forecast_")
## all_drms <-
##   ls(pattern = "^(baseline|drm_|sdm)")
## 
## forecasts_summary <-
##   Map(f = \(x, nm) {
##     fct <- get(x)
##     fct$draws(variables = "y_proj",
##               format = "draws_df") |>
##       tidyr::pivot_longer(cols = starts_with("y_proj"),
##                           names_to = "pair",
##                           values_to = "expected") |>
##       group_by(pair) |>
##       summarise(ll = quantile(expected, probs = .05),
##                 l = quantile(expected, probs = .1),
##                 m = median(expected),
##                 u = quantile(expected, probs = .9),
##                 uu = quantile(expected, probs = .95)) |>
##       ungroup() |>
##       mutate(pair = gsub("\\D", "", pair)) |>
##       mutate(pair = as.integer(pair)) |>
##       arrange(pair) |>
##       mutate(model = nm,
##              .before = 1)
##   }, x = all_forecasts, nm = all_drms)
## 
## forecasts_summary <-
##   bind_rows(forecasts_summary)
## 
## forecasts_summary <-
##   dat_test |>
##   select(dens, lat_floor, patch, year) |>
##   mutate(pair = row_number()) |>
##   left_join(forecasts_summary, by = "pair")


## -----------------------------------------------------------------------------
#| label: forecasts
#| eval: false
#| echo: false

## if (instantiate::stan_cmdstan_exists()) {
##   forecast_0 <- predict_drm(drm = baseline,
##                             new_data = dat_test,
##                             seed = 125,
##                             cores = 4)
## 
##   forecast_1 <- predict_drm(drm = drm_1,
##                             new_data = dat_test,
##                             seed = 125,
##                             cores = 4)
## 
##   forecast_2 <- predict_drm(drm = drm_2,
##                             new_data = dat_test,
##                             past_data = filter(dat_train,
##                                                year == max(year)),
##                             seed = 125,
##                             cores = 4)
## 
##   forecast_3 <- predict_drm(drm = drm_3,
##                             new_data = dat_test,
##                             past_data = filter(dat_train,
##                                                year == max(year)),
##                             seed = 125,
##                             cores = 4)
## 
##   forecast_4 <- predict_drm(drm = drm_4,
##                             new_data = dat_test,
##                             past_data = filter(dat_train,
##                                                year == max(year)),
##                             seed = 125,
##                             cores = 4)
## 
##   forecast_5 <- predict_drm(drm = drm_5,
##                             new_data = dat_test,
##                             past_data = filter(dat_train,
##                                                year == max(year)),
##                             seed = 125,
##                             cores = 4)
## 
##   forecast_6 <- predict_drm(drm = drm_6,
##                             new_data = dat_test,
##                             past_data = filter(dat_train,
##                                                year == max(year)),
##                             f_test = f_test,
##                             seed = 125,
##                             cores = 4)
## 
##   forecast_7 <- predict_drm(drm = drm_7,
##                             new_data = dat_test,
##                             past_data = filter(dat_train,
##                                                year == max(year)),
##                             seed = 125,
##                             cores = 4)
## 
##   forecast_sdm <-
##     predict_sdm(sdm = sdm,
##                 new_data = dat_test,
##                 seed = 125,
##                 cores = 4)
## 
##   ##--- summarizing forecasts ----
## 
##   all_forecasts <-
##     ls(pattern = "^forecast_")
##   all_drms <-
##     ls(pattern = "^(baseline|drm_|sdm)")
## 
##   forecasts_summary <-
##     Map(f = \(x, nm) {
##       fct <- get(x)
##       fct$draws(variables = "y_proj",
##                 format = "draws_df") |>
##         tidyr::pivot_longer(cols = starts_with("y_proj"),
##                             names_to = "pair",
##                             values_to = "expected") |>
##         group_by(pair) |>
##         summarise(ll = quantile(expected, probs = .05),
##                   l = quantile(expected, probs = .1),
##                   m = median(expected),
##                   u = quantile(expected, probs = .9),
##                   uu = quantile(expected, probs = .95)) |>
##         ungroup() |>
##         mutate(pair = gsub("\\D", "", pair)) |>
##         mutate(pair = as.integer(pair)) |>
##         arrange(pair) |>
##         mutate(model = nm,
##                .before = 1)
##     }, x = all_forecasts, nm = all_drms)
## 
##   forecasts_summary <-
##     bind_rows(forecasts_summary)
## 
##   forecasts_summary <-
##     dat_test |>
##     select(dens, lat_floor, patch, year) |>
##     mutate(pair = row_number()) |>
##     left_join(forecasts_summary, by = "pair")
## }


## -----------------------------------------------------------------------------
#| label: assess
#| eval: false

## forecasts_summary |>
##   mutate(bias = dens - m) |>
##   mutate(rmse = bias * bias) |>
##   mutate(is = int_score(dens, l = l, u = u, alpha = .2)) |>
##   mutate(cvg = 100 * dplyr::between(dens, l, u)) |>
##   ungroup() |>
##   group_by(model) |>
##   summarise(across(rmse:cvg, mean)) |>
##   ungroup() |>
##   rename_all(toupper) |>
##   rename("Model" = "MODEL",
##          "IS (80%)" = "IS",
##          "PIC (80%)" = "CVG") |>
##   left_join(aux_qt,
##             by = "Model") |>
##   arrange(desc(LOOIC)) |>
##   relocate(LOOIC, .after = "Model")

