## -----------------------------------------------------------------------------
#| label: setup

library(drmr)
library(sf) ## "mapping"
library(ggplot2) ## graphs
library(bayesplot) ## and more graphs
library(dplyr)


## -----------------------------------------------------------------------------
#| label: data
data(sum_fl)


## -----------------------------------------------------------------------------
#| label: split
## 5 years-ahead predictions
first_year_forecast <- max(sum_fl$year) - 5

first_id_forecast <-
  first_year_forecast - min(sum_fl$year) + 1

years_all <- length(unique(sum_fl$year))
years_train <- years_all[years_all < first_id_forecast]
years_test <- years_all[years_all >= first_id_forecast]

## splitting data
dat_test <- sum_fl |>
  filter(year >= first_year_forecast)

dat_train <- sum_fl |>
  filter(year < first_year_forecast)


## -----------------------------------------------------------------------------
#| label: ytransform
dat_train <- dat_train |>
  mutate(dens = y / area_km2,
         .before = y)

dat_test <- dat_test |>
  mutate(dens = y / area_km2,
         .before = y)


## -----------------------------------------------------------------------------
#| label: data-format

head(dat_train[, c("year", "patch",  "y", "stemp")],
     n = 10)
tail(dat_train[, c("year", "patch",  "y", "stemp")],
     n = 10)


## -----------------------------------------------------------------------------
#| label: fit_drm_mock
#| eval: false
## mcmc_samples <-
##   fit_drm(.data = dat_train,
##           y_col = "dens",
##           time_col = "year",
##           site_col = "patch",
##           n_ages = 8,
##           m = 0.25,
##           seed = 2025)


## -----------------------------------------------------------------------------
#| label: fit_drm
#| echo: false

if (instantiate::stan_cmdstan_exists()) {
  mcmc_samples <-
    fit_drm(.data = dat_train,
            y_col = "dens",
            time_col = "year",
            site_col = "patch",
            n_ages = 8,
            m = 0.25,
            seed = 2025)
}


## -----------------------------------------------------------------------------
#| label: traceplot_mock
#| fig-alt: "MCMC diagnostic plots for the DRM, arranged in two columns and
#| three rows. The left column displays trace plots for four parallel MCMC
#| chains, assessing convergence. The right column displays the estimated
#| posterior density plots for each parameter, assessing mixing. Row 1:
#| sigma_obs parameter; Row 2: coef_t parameter; Row 3: coef_r parameter. All
#| parameters show evidence of good chain convergence and mixing."
#| eval: false
## mcmc_samples$stanfit$draws(variables = c("phi",
##                                          "beta_t",
##                                          "beta_r")) |>
##   mcmc_combo(combo = c("trace", "dens_overlay"),
##              facet_args = list(labeller = label_parsed))


## -----------------------------------------------------------------------------
#| label: traceplot
#| fig-alt: "MCMC diagnostic plots for the DRM, arranged in two columns and
#| three rows. The left column displays trace plots for four parallel MCMC
#| chains, assessing convergence. The right column displays the estimated
#| posterior density plots for each parameter, assessing mixing. Row 1:
#| sigma_obs parameter; Row 2: coef_t parameter; Row 3: coef_r parameter. All
#| parameters show evidence of good chain convergence and mixing."
#| echo: false
if (instantiate::stan_cmdstan_exists()) {
  mcmc_samples$stanfit$draws(variables = c("phi",
                                           "beta_t",
                                           "beta_r")) |>
    mcmc_combo(combo = c("trace", "dens_overlay"),
               facet_args = list(labeller = label_parsed))
}

