##' drmr: Dynamic Range Models in Stan
##' @name drmr
##' @description Fitting process-based species distribution models in stan.
##' @family help
##' @importFrom instantiate stan_package_model
"_PACKAGE"
