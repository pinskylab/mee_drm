
<!-- README.md is generated from README.Rmd. Please edit that file -->

# drmr

## **D**ynamic **R**ange **M**odels in **R**

<!-- badges: start -->

[![R-CMD-check](https://github.com/pinskylab/drmr/workflows/check-cran/badge.svg)](https://github.com/pinskylab/drmr/actions)
[![Lifecycle:
experimental](https://img.shields.io/badge/lifecycle-experimental-orange.svg)](https://lifecycle.r-lib.org/articles/stages.html#experimental)
<!-- badges: end -->

### Installation

The installation of the development version from GitHub can be done via

``` r
remotes::install_github("pinskylab/drmr")
## or devtools::install_github("pinskylab/drmr")
```
